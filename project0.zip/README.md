# Project 0

Web Programming with Python and JavaScript

The project contains two html files in English and their identical versions in Spanish.

Bootstrap 4 was used, with additions of its own css, for the navigation bar of the four files and for the first table of the blog.

All local css was written to an scss file and compiled to css using Prepros.

It is the preference of this inexperienced student to use "class" selectors instead of another type of selector.

To meet project specifications, html tags and ID selectors were used, which could perhaps be considered far from good practice.

The content is not intended to instruct the reader but to be functional for the project. Rather, it aims to make the reader look for more information on the subject.